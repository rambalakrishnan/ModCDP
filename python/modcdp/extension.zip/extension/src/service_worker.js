// Extension service worker entry point.
import "./config.js";
import { ModCDPServer } from "../../js/src/server/ModCDPServer.js";
const ModCDP = globalThis.ModCDP;
const bridge = (ModCDP ?? ModCDPServer);
const started_at = new Date().toISOString();
const runtime_config = globalThis.__MODCDP_RUNTIME_CONFIG__;
const downstream_clients = {};
const upstream_servers = {};
const client_id_by_config_session = new Map();
let active_downstream_client_id = null;
let next_downstream_client_id = 1;
let next_log_id = 1;
const self_transports = {};
const self_custom = { commands: new Set(), events: new Set() };
const self_log = [];
const compact = (value) => JSON.parse(JSON.stringify(value ?? null));
const trimLog = (log) => (log.length = Math.min(log.length, 80));
const routeFor = (method) => {
    if (method.startsWith("Mod.") || method.startsWith("Custom."))
        return "service_worker";
    const routes = (bridge.routes ?? {});
    const route = routes[method] ??
        Object.entries(routes)
            .filter(([pattern]) => pattern.endsWith(".*") && method.startsWith(pattern.slice(0, -1)))
            .sort((a, b) => b[0].length - a[0].length)[0]?.[1] ??
        routes["*.*"] ??
        "chrome_debugger";
    if (route === "loopback_cdp")
        return "loopback";
    if (route === "chrome_debugger")
        return "debugger";
    if (route === "auto")
        return bridge.loopback_cdp_url ? "loopback" : "debugger";
    return route;
};
const upstreamServer = (id) => (upstream_servers[id] ??= {
    id,
    log: [],
});
const configuredClient = (params, session_id) => {
    const at = new Date().toISOString();
    const id = (session_id && client_id_by_config_session.get(session_id)) || `downstream_client_${next_downstream_client_id++}`;
    if (session_id)
        client_id_by_config_session.set(session_id, id);
    active_downstream_client_id = id;
    const configure = compact(params);
    const client = (downstream_clients[id] ??= {
        id,
        configured_at: at,
        commands: 0,
        events: 0,
        sessions: {},
        recent: [],
    });
    client.updated_at = at;
    client.configure = configure;
    client.downstream_transport =
        configure?.upstream?.upstream_mode ?? "unknown";
    client.route_config = {
        upstream: configure?.upstream ?? {},
        client: configure?.client ?? {},
        server: configure?.server ?? {},
    };
    if (client.downstream_transport !== "reversews") {
        bridge.stopReverseBridge?.("non-reverse downstream connected");
    }
    return client;
};
const downstreamClient = (session_id) => {
    const at = new Date().toISOString();
    const client_id = (session_id && client_id_by_config_session.get(session_id)) ||
        active_downstream_client_id ||
        "unconfigured_downstream_client";
    const client = (downstream_clients[client_id] ??= {
        id: client_id,
        commands: 0,
        events: 0,
        sessions: {},
        recent: [],
        first_seen: at,
        last_seen: at,
    });
    const id = session_id || "root";
    const session = (client.sessions[id] ??= { id, commands: 0, events: 0, first_seen: at, last_seen: at });
    return { at, client_id, client, session };
};
const logTraffic = (direction, name, payload, session_id) => {
    const { at, client_id, client, session } = downstreamClient(session_id);
    const upstream = routeFor(name);
    const from = direction === "command" ? client_id : upstream;
    const to = direction === "command" ? upstream : client_id;
    const route_path = from === "service_worker" || to === "service_worker" ? [from, to] : [from, "service_worker", to];
    const entry = {
        id: `log_${next_log_id++}`,
        at,
        direction,
        method: name,
        payload: compact(payload),
        route_path,
        downstream_transport: client.downstream_transport ?? "unknown",
        cdp_session_id: session_id ?? null,
    };
    direction === "event" ? client.events++ : client.commands++;
    direction === "event" ? session.events++ : session.commands++;
    direction === "event" ? (session.last_event = name) : (session.last_command = name);
    client.last_seen = at;
    session.last_seen = at;
    client.log ??= client.recent ?? [];
    client.log.unshift(entry);
    trimLog(client.log);
    const endpointLog = upstream === "service_worker" ? self_log : upstreamServer(upstream).log;
    endpointLog.unshift(entry);
    trimLog(endpointLog);
    return entry;
};
if (bridge) {
    const handleCommand = bridge.handleCommand?.bind(bridge);
    if (handleCommand) {
        bridge.handleCommand = async (method, params, session_id) => {
            if (method === "Mod.configure")
                configuredClient(params, session_id);
            const entry = logTraffic("command", method, params, session_id);
            try {
                const result = await handleCommand(method, params, session_id);
                entry.result = compact(result);
                entry.completed_at = new Date().toISOString();
                return result;
            }
            catch (error) {
                entry.error = error instanceof Error ? error.message : String(error);
                entry.completed_at = new Date().toISOString();
                throw error;
            }
        };
    }
    bridge.addEventListener?.((event, _payload, session_id) => logTraffic("event", event, _payload, session_id));
    for (const [method, key] of [
        ["startReverseBridge", "reverse"],
        ["stopReverseBridge", "reverse"],
        ["startNativeBridge", "native"],
        ["startNatsBridge", "nats"],
    ]) {
        const start = bridge[method]?.bind(bridge);
        if (start) {
            bridge[method] = (...args) => {
                const result = start(...args);
                self_transports[key] = { args: compact(args), result: compact(result), updated_at: new Date().toISOString() };
                return result;
            };
        }
    }
    for (const [method, key] of [
        ["addCustomCommand", "commands"],
        ["addCustomEvent", "events"],
    ]) {
        const add = bridge[method]?.bind(bridge);
        if (add) {
            bridge[method] = (name, ...args) => {
                self_custom[key].add(name);
                return add(name, ...args);
            };
        }
    }
}
const startConfiguredTransports = () => {
    const config = runtime_config ?? {};
    bridge.startOffscreenKeepAlive?.();
    if (config.upstream_reversews_url) {
        bridge.startReverseBridge?.(config.upstream_reversews_url, { reconnect_interval_ms: 2_000 });
    }
    if (config.upstream_nativemessaging_host_name) {
        bridge.startNativeBridge?.(config.upstream_nativemessaging_host_name, { reconnect_interval_ms: 2_000 });
    }
    if (config.upstream_nats_url) {
        bridge.startNatsBridge?.(config.upstream_nats_url, {
            upstream_nats_subject_prefix: config.upstream_nats_subject_prefix,
            reconnect_interval_ms: 2_000,
        });
    }
};
startConfiguredTransports();
chrome.runtime.onInstalled.addListener(startConfiguredTransports);
chrome.runtime.onStartup.addListener(startConfiguredTransports);
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "modcdp.wake") {
        startConfiguredTransports();
        sendResponse({
            ok: true,
            extension_id: chrome.runtime.id,
            service_worker_url: chrome.runtime.getURL("modcdp/service_worker.js"),
        });
        return false;
    }
    if (message?.type !== "modcdp.options.status")
        return false;
    const self = {
        id: "self",
        runtime: {
            extension_id: chrome.runtime.id,
            service_worker_url: chrome.runtime.getURL("modcdp/service_worker.js"),
            options_url: chrome.runtime.getURL("options.html"),
            started_at,
        },
        server: {
            __ModCDPServerVersion: bridge.__ModCDPServerVersion,
            routes: bridge.routes,
            loopback_cdp_url: bridge.loopback_cdp_url,
            browser_token: bridge.browser_token ? "set" : null,
            cdp_send_timeout_ms: bridge.cdp_send_timeout_ms,
            loopback_execution_context_timeout_ms: bridge.loopback_execution_context_timeout_ms,
            ws_connect_error_settle_timeout_ms: bridge.ws_connect_error_settle_timeout_ms,
            native_bridge_attempts: bridge.native_bridge_attempts,
            native_bridge_connected: bridge.native_bridge_connected,
            native_bridge_last_error: bridge.native_bridge_last_error,
        },
        ...(Object.keys(self_transports).length ? { transports: self_transports } : {}),
        custom: { commands: [...self_custom.commands], events: [...self_custom.events] },
        log: self_log,
    };
    sendResponse({
        now: new Date().toISOString(),
        self,
        downstream_clients,
        upstream_servers: {
            ...upstream_servers,
            ...(bridge.loopback_cdp_url
                ? {
                    loopback: {
                        ...upstream_servers.loopback,
                        id: "loopback",
                        url: bridge.loopback_cdp_url,
                        log: upstream_servers.loopback?.log ?? [],
                    },
                }
                : {}),
            debugger: { ...upstream_servers.debugger, id: "debugger", log: upstream_servers.debugger?.log ?? [] },
        },
    });
    return false;
});
chrome.action?.onClicked.addListener(() => {
    void chrome.runtime.openOptionsPage();
});
//# sourceMappingURL=service_worker.js.map